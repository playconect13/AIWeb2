#!/bin/bash
chat_id=$1

TOKEN=$(cat /bin/ppweb/botpag/token-bot)

ip_server=$(cat /bin/ppweb/botpag/ip-serv-ssh)

senha_server=$(cat /bin/ppweb/botpag/senha-serv-ssh)

URL="https://api.telegram.org/bot$TOKEN/sendMessage"

nome=$(echo $RANDOM | md5sum | head -c 9; echo;)
if [[ -z $nome ]]
then
	exit 1
fi
awk -F : ' { print $1 }' /etc/passwd > /tmp/users 
if grep -Fxq "$nome" /tmp/users
then
	 	exit 1
fi
pass=$(echo $RANDOM | md5sum | head -c 5; echo;)
if [[ -z $pass ]]
then
	exit 1
fi
limit=1
if [[ -z $limit ]]
then
exit 1
fi
u_temp=360
if [[ -z $u_temp ]]
then
	exit 1
fi
final=$(date "+%Y-%m-%d" -d "+1 days")
sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server echo "ok" 1>/dev/null 2>/dev/null
sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server << EOF
mkdir /etc/SSHPlus/userteste > /dev/null 2>&1
useradd -e $final -M -s /bin/false -p $pass $nome >/dev/null 2>&1 &
(echo $pass;echo $pass) |passwd $nome > /dev/null 2>&1
echo "$pass" > /etc/SSHPlus/senha/$nome
echo "$nome $limit" >> /root/usuarios.db
echo "#!/bin/bash
pkill -f "$nome"
userdel --force $nome
grep -v ^$nome[[:space:]] /root/usuarios.db > /tmp/ph ; cat /tmp/ph > /root/usuarios.db
rm /etc/SSHPlus/senha/$nome > /dev/null 2>&1
rm -rf /etc/SSHPlus/userteste/$nome.sh
exit" > /etc/SSHPlus/userteste/$nome.sh
chmod +x /etc/SSHPlus/userteste/$nome.sh
at -f /etc/SSHPlus/userteste/$nome.sh now + $u_temp min > /dev/null 2>&1
EOF

curl -s -X POST $URL -d chat_id=$chat_id -d text="
<b>TESTE CRIADO COM SUCESSO!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Usuário: $nome
Senha: $pass
Expira em: 6 Hrs
Limite de conexões: $limit
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Depois do tempo de $u_temp terminar
Sera desconectado e aconta deletada
" -d parse_mode="HTML"